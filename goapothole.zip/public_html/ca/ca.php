 <link rel="stylesheet" href="styles.css">
<?php
 
     $email =  $_COOKIE["email"];
     $cidname ='cid';
     $userimgurlname = 'userimgurlname';
      $userphonenumbername = 'userphonenumbername';
     
$servername = "localhost";
$username = "id12183512_goapothole";
$password = "goapothole";
$dbname = "id12183512_goapothole";


// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
$sql = "SELECT * FROM complaint where caemail = '$email'";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
    // output data of each row
    while($row = mysqli_fetch_assoc($result)) {
        echo "<div class='container'>";
       $cid = $row["cid"];
       $pincode = $row["pincode"];
       $userimgurl = $row["imgurl"];
       $lat = $row["latitude"];
       $long = $row["longitude"];
       $userphonenumber = $row["userphonenumber"];
        echo "<br>";
         //echo $row["latitude"];
         //echo "<br>";
         // echo $row["longitude"];
         // echo "<br>";
          echo "<a href=https://www.google.com/maps/place/$lat,$long><button class='button'><span>Location</span></button></a>";
          echo "<br/>";
           //echo $row["userphonenumber"];
           //echo "<br>";
            //  echo $row["pincode"];
           //echo "<br>";
           echo "<img src=" . $row['imgurl'] . "height='auto' width='100%'/>";
            echo "<br>";
              echo $row["date"];
               echo "<br>";
               //echo "<br>";
                    echo '<form method="post" action="fixed.php" class="container">';
               echo "<input  type='text' name='$cidname' value=$cid style='display:none;'/>";
                echo "<input  type='text' name='pincode' value=$pincode style='display:none;'/>";
               echo "<input  type='text' name='$userimgurlname'  value=$userimgurl style='display:none;'/>";
               echo "<input  type='text' name='$userphonenumbername'  value=$userphonenumber style='display:none;'/>";
               echo "<center><button class='button'><span>FIXED</span></button></center>";
               echo "</form>";
               echo "<br>";
               echo "<br>";
               echo "</div>";
                echo "<br>";
    }
} else {
    echo "<center>YOU CURRENTLY HAVE NO COMPLAINT ASSIGNED TO YOU</center>";
}

?>

<!-- Complain Form -->
 <form class="container" id="complainform" action="complain.php" method="post" style="display:none">
 
  <div style="float:right;"> Status:</div>
  <br/>
                 <label class="switch" style="float:right;">
  <input type="checkbox" checked>
  <span class="slider round"></span>
</label>
    <center><h4>COMPLAINT DETAILS</h4></center>
    <br/>
        <br/>

 
 <br/>

     
     <input id="complainimg" type="file" name="complainimg" style="width:100%;" accept=".png, .jpg, .jpeg">
        <progress value="0" max="100" id="uploader"></progress>
      <div>
            <div id="imagePreview">
            <img id="img" width="100%" src="../image/logo.png" style="display:none;">
            </div>
        </div>
     
            <br/>
             <div class="form-group" style="display:none;">
<input  type="text" name="email" id="email" value="" readonly/>
              <label for="input" class="control-label">PHONE NUMBER</label><i class="bar"></i>
            </div> 
            <br/>
       
            
 

            <br>
            <div class="form-group" style="display:none;">
<input  type="text" name="imgurl" id="imgurl" value="" readonly/>
              <label for="input" class="control-label">imgurl</label><i class="bar"></i>
            </div>   

                  
                  <br/>
     <center><button  class="button"  id="submitcomplain" style="display:none;"><span>SUBMIT</span></button></center>
<br/>
</form>


<script>
//for the image
  function readURL(input) {
    if (input.files && input.files[0]) {
        var reader = new FileReader();
        reader.onload = function(e) {
            $('#img').attr({ src: e.target.result});
            $('#imagePreview').hide();
            $('#imagePreview').fadeIn(650);
        }
        reader.readAsDataURL(input.files[0]);
    }
}
$("#complainimg").change(function() {
    readURL(this);
});


//to upload the image and get the download link for the image and display it in html
var artup = document.getElementById('complainimg');

var uploader = document.getElementById('uploader');
artup.addEventListener('change', function(e){
  var file = e.target.files[0];

  var upart = firebase.storage().ref('complainimg/' + file.name);
  // console.log(upart);
  var load = upart.put(file);
  load.on('state_changed',
  function progress(snapshot){
    var percentage = (snapshot.bytesTransferred / snapshot.totalBytes) * 100;
    uploader.value = percentage;
  },
  
  //runs if there is an error in uploading
    function error(err){
      alert("error");
    },

    //runs when complainimg is uploaded
    function complete(){
      upart.getDownloadURL().then(function(url) {
         document.getElementById('imgurl').value = url;
        $("#img").attr({
          src: url
        });
    },
  )
  document.getElementById('img').style.display="block";
   document.getElementById('submitcomplain').style.display="block";
    });
});

</script>