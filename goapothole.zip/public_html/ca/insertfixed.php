<link rel="stylesheet" href="styles.css">
<?php
$servername = "localhost";
$username = "id12183512_goapothole";
$password = "goapothole";
$dbname = "id12183512_goapothole";

$cid = $_POST["cid"];
$userimgurl = $_POST["userimgurl"];
$caimgurl = $_POST["imgurl"];
$pincode = $_POST["pincode"];
$userphonenumber = $_POST["userphonenumber"];
$caemail = $_POST["email"];



// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
$sql = "INSERT INTO fixed (cid, pincode, userphonenumber, caemail, userimgurl, caimgurl, date)
    VALUES ($cid, $pincode, $userphonenumber, '$caemail', '$userimgurl', '$caimgurl',  CURDATE())";

if (mysqli_query($conn, $sql)) {
    $sql1 = "DELETE FROM complaint WHERE cid = $cid";
$sql2 = "UPDATE ca SET noc = noc - 1 where email = '$caemail'";
 mysqli_query($conn, $sql1);
    mysqli_query($conn, $sql2);
mysqli_query($conn, $sql1);
    echo "<div class='container'><center><b>SOLUTION SUBMITTED!!! </b></center> <br/> <center><span><a href=https://goapothole.000webhostapp.com/ca/><button class='button'><span>Help Build Goa</span></button></a></span></center></div>";
} else {
    echo "<div class='container'><center><b>ERROR!!!!</b></center> <br/> <center><a href=https://goapothole.000webhostapp.com/ca/><button class='button'><span>Help Build Goa</span></button></a></center></div>";
}

?>