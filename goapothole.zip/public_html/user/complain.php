<link rel="stylesheet" href="styles.css">
<?php
$servername = "localhost";
$username = "id12183512_goapothole";
$password = "goapothole";
$dbname = "id12183512_goapothole";


$phonenumber = $_POST["phonenumber"];
$pincode = $_POST["pincode"];
$imgurl = $_POST["imgurl"];
$longitude = $_POST["longitude"];
$latitude = $_POST["latitude"];
$phonenumber =  substr($phonenumber,1);

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
 $sql = "INSERT INTO complaint (latitude, longitude, pincode, userphonenumber, imgurl, date)
    VALUES ('$latitude', '$longitude', $pincode, $phonenumber, '$imgurl', CURDATE())";
    
    mysqli_query($conn, $sql);
$cidd = mysqli_query($conn, "select email from ca where pincode = $pincode and noc < 3 LIMIT 1");
if (mysqli_num_rows($cidd) > 0) {
    // output data of each row
    $i=0;
    while(($cid = mysqli_fetch_assoc($cidd)) && $i<1) {
        $i++;
       $sql1 = "INSERT INTO complaint (latitude, longitude, pincode, userphonenumber, imgurl, caemail, date)
    VALUES ('$latitude', '$longitude', $pincode, $phonenumber, '$imgurl', '$cid[email]', CURDATE())";
    $sql2 = "UPDATE ca SET noc = noc + 1 where email = '$cid[email]'";
    }
    mysqli_query($conn, $sql1);
     mysqli_query($conn, $sql2);
    echo "Complaint Submitted!!! <br/> <center><a href=https://goapothole.000webhostapp.com/user/>Help Build Goa</a></center>";
}
else{
    echo "We currently have no Agency around you. We will look into your complaint <br/> <center><a href=https://goapothole.000webhostapp.com/user/>Help Build Goa</a></center>";
}
//$sql = "INSERT INTO complaint (userphonenumber, pincode, latitude, longitude, imgurl, caphonenumber)
 //   VALUES ($phonenumber, $pincode, '$latitude', '$longitude', '$imgurl', $cidd )";

 

?>