 // Your web app's Firebase configuration
  var firebaseConfig = {
    apiKey: "AIzaSyBIHDt3IWtK7yw0fwIRmByz5AgLJ2pTm6M",
    authDomain: "jntuhat.firebaseapp.com",
    databaseURL: "https://jntuhat.firebaseio.com",
    projectId: "jntuhat",
    storageBucket: "gs://jntuhat.appspot.com/",
    messagingSenderId: "585431580345",
    appId: "1:585431580345:web:d606192627bee027"
  };
  // Initialize Firebase
  firebase.initializeApp(firebaseConfig);

    
  