 <link rel="stylesheet" href="styles.css">
<?php
 
     $phonenumber =  $_POST["userphonenumber"];
     
$servername = "localhost";
$username = "id12183512_goapothole";
$password = "goapothole";
$dbname = "id12183512_goapothole";
$phonenumber = substr($phonenumber,1);


// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
$sql = "SELECT * FROM fixed where userphonenumber = '$phonenumber'";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
    // output data of each row
    while($row = mysqli_fetch_assoc($result)) {
        echo "<div class='container'>";
       $userimgurl = $row["userimgurl"];
       $caimgurl = $row["caimgurl"];
       echo "BEFORE";
           echo "<img src=" . $row['userimgurl'] . "height='auto' width='100%'/>";
            echo "<br>";
            echo "<br>";
            echo "<br>";
            echo "AFTER";
                     echo "<img src=" . $row['caimgurl'] . "height='auto' width='100%'/>";
               echo "<br>";
               echo "<br>";
               echo "<br>";
               echo "</div>";
                echo "<br>";
    }
} else {
    echo "YOU HAVE NO SOLVED COMPLAINT";
}

?>