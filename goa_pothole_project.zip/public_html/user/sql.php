<link rel="stylesheet" href="styles.css">
<?php
$servername = "localhost";
$username = "id12183512_goapothole";
$password = "goapothole";
$dbname = "id12183512_goapothole";


$phonenumber = $_POST["phonenumber"];
$pincode = $_POST["savepincode"];
echo $phonenumber;
echo $pincode;
//$gender = $_POST["gender"];
$phonenumber =  substr($phonenumber,1);

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
$sql = "INSERT INTO user (phonenumber, pincode )
    VALUES ($phonenumber, $pincode)";

if (mysqli_query($conn, $sql)) {
    echo "Profile Saved!!! <br/> <center><a href=https://goapothole.000webhostapp.com/user/>Help Build Goa</a></center>";
} else {
    echo "Profile Already Exist!! <br/> <center><a href=https://goapothole.000webhostapp.com/user/>Help Build Goa</a></center>";
}

?>
    <script>
var savepincode = "<?php echo $_POST["savepincode"] ?>";
localStorage.setItem("pincode",savepincode);
</script>