<link rel="stylesheet" href="styles.css">
<?php
$servername = "localhost";
$username = "id12183512_goapothole";
$password = "goapothole";
$dbname = "id12183512_goapothole";

$phonenumber = $_POST["phonenumber"];
$pincode = $_POST["savepincode"];


// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
$sql = "INSERT INTO ca (phonenumber, pincode, gender)
    VALUES ($phonenumber, $pincode, '$gender')";

if (mysqli_query($conn, $sql)) {
    echo "<div class='container'><center><b>Profile Saved!!!</b> <br/> <center><a href=https://acecal.000webhostapp.com/goa/><button class='button'><span>Help Build Goa</span></button></a></center></div>";
} else {
    echo "<div class='container'><center><b>Profile Already Exist!! </b><br/> <center><a href=https://acecal.000webhostapp.com/goa/><button class='button'><span>Help Build Goa</span></button></a></center></div>";
}

?>
<script>
var savepincode = <?php echo $_POST["savepincode"] ?>;
localStorage.setItem("pincode",savepincode);
</script>