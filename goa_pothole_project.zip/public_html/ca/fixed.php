<!DOCTYPE html>
<html>
  <head>

    <meta charset="UTF-8">
    <title>POTHOLE RECTIFICATION SYSTEM</title>
<!-- Firebase -->
<script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
<script src="https://www.gstatic.com/firebasejs/7.6.1/firebase-app.js"></script>
<script src="https://www.gstatic.com/firebasejs/7.6.1/firebase-auth.js"></script>
<script src="https://www.gstatic.com/firebasejs/7.6.1/firebase-firestore.js"></script>
       <script src="https://www.gstatic.com/firebasejs/7.6.1/firebase-storage.js"></script>
       
        <script>
 // Your web app's Firebase configuration
    var firebaseConfig = {
    apiKey: "AIzaSyCJ4VOKZ5DWI4Gjnyr-hZLRXeqsZTrfykg",
    authDomain: "goapothole.firebaseapp.com",
    databaseURL: "https://goapothole.firebaseio.com",
    projectId: "goapothole",
    storageBucket: "goapothole.appspot.com",
    messagingSenderId: "444456422648",
    appId: "1:444456422648:web:c3032fa57da37016fcbf0d"
  };
  // Initialize Firebase
  firebase.initializeApp(firebaseConfig);
  </script>
    <link rel="stylesheet" href="styles.css">

  </head>
  <body>
      
    <!-- The surrounding HTML is left untouched by FirebaseUI.
         Your app may use that space for branding, controls and other customizations.-->
         
         <form method="post" class="container" action="insertfixed.php">
 
    <center><h4>COMPLAIN DETAILS</h4></center>
    <br/>
        <br/>

 
 <br/>

     
     <input id="complainimg" type="file" name="complainimg" style="width:100%;" accept=".png, .jpg, .jpeg">
        <progress value="0" max="100" id="uploader"></progress>
      <div>
            <div id="imagePreview">
            <img id="img" width="100%" src="" style="display:none;">
            </div>
        </div>
     
            <br/>
             <div class="form-group" >
<input  type="text" name="email" id="email" value="" readonly/>
     <label for="input" class="control-label">CA Email</label><i class="bar"></i>
            </div> 
            <br/>
             <div class="form-group" >
<input  type="text" name="pincode" id="pincode" value="" readonly/>
     <label for="input" class="control-label">PINCODE</label><i class="bar"></i>
            </div> 
            <br/>
    
            <div class="form-group">
<input  type="text" name="cid" id="cid" value="" readonly/>
     <label for="input" class="control-label">CID</label><i class="bar"></i>
            </div>  

            <br>
            <div class="form-group">
<input  type="text" name="imgurl" id="imgurl" value="" readonly/>
     <label for="input" class="control-label">CA IMG URL</label><i class="bar"></i>
            </div>   
              <br>
               <div class="form-group">
<input  type="text" name="userphonenumber" id="userphonenumber" value="" readonly/>
     <label for="input" class="control-label">USER PHONENUMBER</label><i class="bar"></i>
            </div>   
              <br>
            <div class="form-group">
<input  type="text" name="userimgurl" id="userimgurl" value="" readonly/>
     <label for="input" class="control-label">USER IMG URL</label><i class="bar"></i>
            </div> 

                  
                  <br/>
     <center><button  class="button"  id="submitcomplain" style="display:none;"><span>SUBMIT</span></button></center>
<br/>
</form>


<script>
//for the image
  function readURL(input) {
    if (input.files && input.files[0]) {
        var reader = new FileReader();
        reader.onload = function(e) {
            $('#img').attr({ src: e.target.result});
            $('#imagePreview').hide();
            $('#imagePreview').fadeIn(650);
        }
        reader.readAsDataURL(input.files[0]);
    }
}
$("#complainimg").change(function() {
    readURL(this);
});


//to upload the image and get the download link for the image and display it in html
var artup = document.getElementById('complainimg');

var uploader = document.getElementById('uploader');
artup.addEventListener('change', function(e){
  var file = e.target.files[0];

  var upart = firebase.storage().ref('potholeimg/' + file.name);
  // console.log(upart);
  var load = upart.put(file);
  load.on('state_changed',
  function progress(snapshot){
    var percentage = (snapshot.bytesTransferred / snapshot.totalBytes) * 100;
    uploader.value = percentage;
  },
  
  //runs if there is an error in uploading
    function error(err){
      alert("error");
    },

    //runs when complainimg is uploaded
    function complete(){
      upart.getDownloadURL().then(function(url) {
         document.getElementById('imgurl').value = url;
        $("#img").attr({
          src: url
        });
    },
  )
  document.getElementById('img').style.display="block";
   document.getElementById('submitcomplain').style.display="block";
    });
});

</script>

    <script>

                var email =  "<?php echo $_COOKIE["email"]; ?>";
            var cid = "<?php echo $_POST["cid"]; ?>";
            var userimgurl =   '<?php echo $_POST["userimgurlname"]; ?>';
                    var pincode =   '<?php echo $_POST["pincode"]; ?>';
                                        var userphonenumber =   '<?php echo $_POST["userphonenumbername"]; ?>';
  document.getElementById("userphonenumber").value = userphonenumber;
  document.getElementById("pincode").value = pincode;
  document.getElementById("userimgurl").value = userimgurl;
  document.getElementById("email").value = email;
   document.getElementById("cid").value = cid;
        
    </script>
  </body>
</html>