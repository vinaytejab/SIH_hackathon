<!DOCTYPE html>
<html>
  <head>

    <meta charset="UTF-8">
    <title>POTHOLE RECTIFICATION SYSTEM</title>
<!-- Firebase -->
<script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
<script src="https://www.gstatic.com/firebasejs/7.6.1/firebase-app.js"></script>
<script src="https://www.gstatic.com/firebasejs/7.6.1/firebase-auth.js"></script>
<script src="https://www.gstatic.com/firebasejs/7.6.1/firebase-firestore.js"></script>
       <script src="https://www.gstatic.com/firebasejs/7.6.1/firebase-storage.js"></script>
       
         <meta name="viewport" content="initial-scale=1.0,
        width=device-width" />
      <script src="https://js.api.here.com/v3/3.1/mapsjs-core.js"
        type="text/javascript" charset="utf-8"></script>
      <script src="https://js.api.here.com/v3/3.1/mapsjs-service.js"
        type="text/javascript" charset="utf-8"></script>

  <script>
  
  

 // Your web app's Firebase configuration
    var firebaseConfig = {
    apiKey: "AIzaSyCJ4VOKZ5DWI4Gjnyr-hZLRXeqsZTrfykg",
    authDomain: "goapothole.firebaseapp.com",
    databaseURL: "https://goapothole.firebaseio.com",
    projectId: "goapothole",
    storageBucket: "goapothole.appspot.com",
    messagingSenderId: "444456422648",
    appId: "1:444456422648:web:c3032fa57da37016fcbf0d"
  };
  // Initialize Firebase
  firebase.initializeApp(firebaseConfig);
  </script>
    
    <script src="https://www.gstatic.com/firebasejs/ui/4.3.0/firebase-ui-auth.js"></script>
    <link type="text/css" rel="stylesheet" href="https://www.gstatic.com/firebasejs/ui/4.3.0/firebase-ui-auth.css" />
    <script type="text/javascript">

    // Check State change (sign in and sign out)
firebase.auth().onAuthStateChanged(function(user) {
  if (user) {
    // User is signed in.

    var user = firebase.auth().currentUser;
    var email = user.email;
        document.cookie = 'email='+email+'';
        window.location.replace("ca.php");

    if(user != null){
// Display user Phone Number

  
             
        document.getElementById("email").value = email;
 document.getElementById("complainform").style.display = "block";  

}
    }

   else {
    // No user is signed in.
// Display Firebase form for authentication (Since no user is signed in)

   ui.start('#firebaseui-auth-container', uiConfig);
       
         
  }
});
      
    

      var ui = new firebaseui.auth.AuthUI(firebase.auth());
      // The start method will wait until the DOM is loaded.
         // FirebaseUI config.
      var uiConfig = {
        callbacks: {
          signInSuccessWithAuthResult: function(authResult, redirectUrl) {
            var user = authResult.user;
            var credential = authResult.credential;
            var isNewUser = authResult.additionalUserInfo.isNewUser;
            var providerId = authResult.additionalUserInfo.providerId;
            var operationType = authResult.operationType;
            // Do something with the returned AuthResult.
            // Return type determines whether we continue the redirect automatically
            // or whether we leave that to developer to handle.
            return true;
          },
          signInFailure: function(error) {
            // Some unrecoverable error occurred during sign-in.
            // Return a promise when error handling is completed and FirebaseUI
            // will reset, clearing any UI. This commonly occurs for error code
            // 'firebaseui/anonymous-upgrade-merge-conflict' when merge conflict
            // occurs. Check below for more details on this.
            return handleUIError(error);
          },
          uiShown: function() {
            // The widget is rendered.
            // Hide the loader.
            document.getElementById('loader').style.display = 'none';
          }
        },
        credentialHelper: firebaseui.auth.CredentialHelper.ACCOUNT_CHOOSER_COM,
        // Query parameter name for mode.
        queryParameterForWidgetMode: 'mode',
        // Query parameter name for sign in success url.
        queryParameterForSignInSuccessUrl: 'signInSuccessUrl',
        // Will use popup for IDP Providers sign-in flow instead of the default, redirect.
        signInFlow: 'popup',
        signInSuccessUrl: 'ca.php',
        signInOptions: [
          // Leave the lines as is for the providers you want to offer your users.
       
           
              firebase.auth.EmailAuthProvider.PROVIDER_ID
         
        ],
        // Set to true if you only have a single federated provider like
        // firebase.auth.GoogleAuthProvider.PROVIDER_ID and you would like to
        // immediately redirect to the provider's site instead of showing a
        // 'Sign in with Provider' button first. In order for this to take
        // effect, the signInFlow option must also be set to 'redirect'.
        immediateFederatedRedirect: false,
        // tosUrl and privacyPolicyUrl accept eicther url string or a callback
        // function.
        // Terms of service url/callback.
        tosUrl: '<your-tos-url>',
        // Privacy policy url/callback.
        privacyPolicyUrl: function() {
          window.location.assign('<your-privacy-policy-url>');
        }
      };
   
    </script>
    <link rel="stylesheet" href="styles.css">
    
  </head>
  <body>
    <!-- The surrounding HTML is left untouched by FirebaseUI.
         Your app may use that space for branding, controls and other customizations.-->
 <br/>
<!-- Firebase Authentication Form -->
    <div id="firebaseui-auth-container"></div>
    
  </body>
</html>